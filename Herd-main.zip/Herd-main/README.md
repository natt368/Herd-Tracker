# Herd
Herd record keeping

**Rangebook** — a single-file cow/calf herd ledger (`index.html`). Open it in a browser; data is stored locally (`localStorage`) or synced to Google Drive via an Apps Script web app (see the Drive button in the app).

**Live app:** https://peter5757803.github.io/Herd/

**Shared data for a crew on Google Workspace:** open the app's Drive button → *Copy Workspace script*, paste it at script.new, and deploy as a Web app (Execute as **Me**, access **Anyone within your organization**). The Web app URL serves Rangebook inside your Workspace, with everyone signing in with their own Google account and sharing one data file in the deployer's Drive.
